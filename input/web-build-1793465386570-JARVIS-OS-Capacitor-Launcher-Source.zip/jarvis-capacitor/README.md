# JARVIS OS — Capacitor Android project

Capacitor 8 web app with a native Android launcher plugin.

## Included launcher support
- Registers the app activity with Android `MAIN` + `HOME` + `DEFAULT` intent categories so users can choose JARVIS OS as their Home app.
- Discovers apps that expose launcher activities.
- Displays installed app names and Android-provided icons in the app drawer and essentials grid.
- Launches selected apps through Android package launch intents.
- Uses a narrow package-visibility query for launcher activities; it does not request broad `QUERY_ALL_PACKAGES` access.

## Build
The online builder must run the project's npm build and Capacitor Android sync steps. The project includes a local Capacitor plugin in `native-launcher-plugin/`.

Normal Capacitor workflow:
```bash
npm install
npm run build
npx cap add android   # only the first time, if android/ does not exist
npx cap sync android
```
Then build the generated Android project with Gradle. In the online builder, upload this ZIP and select Capacitor.

## Compatibility and caveats
- Intended for Android 9+.
- The builder controls compileSdk/targetSdk (its supplied environment offers API 34–37).
- This is source code, not a compiled APK.
- The generated Android app must preserve Capacitor plugin manifest merging. The local plugin contributes the HOME intent filter to `com.zyvix.jarvisos.MainActivity`; if the builder strips plugin manifests, the app may install without appearing in Android's Home app chooser.
