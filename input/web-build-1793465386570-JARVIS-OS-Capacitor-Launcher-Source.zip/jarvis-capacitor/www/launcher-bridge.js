import { registerPlugin } from '@capacitor/core';

const LauncherApps = registerPlugin('LauncherApps');
window.JarvisLauncherApps = LauncherApps;
window.dispatchEvent(new Event('jarvis-launcher-ready'));
