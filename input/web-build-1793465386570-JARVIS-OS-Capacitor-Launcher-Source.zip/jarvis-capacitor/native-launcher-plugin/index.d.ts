export interface LauncherApp { packageName: string; name: string; icon: string; }
export interface LauncherAppsPlugin {
  getApps(): Promise<{ apps: LauncherApp[] }>;
  launchApp(options: { packageName: string }): Promise<void>;
}
