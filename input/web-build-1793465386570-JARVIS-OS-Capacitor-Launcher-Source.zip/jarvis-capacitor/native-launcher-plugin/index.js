// Capacitor discovers the native implementation from package metadata.
